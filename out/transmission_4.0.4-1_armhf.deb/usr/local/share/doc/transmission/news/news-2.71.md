## [Transmission 2.71](https://trac.transmissionbt.com/query?milestone=2.71&group=component&order=severity) (2012-09-26)
### Mac
 * Fix 2.70 crasher on 10.6 Snow Leopard
