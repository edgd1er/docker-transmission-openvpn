## [Transmission 2.52](https://trac.transmissionbt.com/query?milestone=2.52&group=component&order=severity) (2012-05-19)
### All Platforms
 * Fix bug with zero termination of multiscrape strings
 * Update the bundled libnatpmp and miniupnp port forwarding libraries
### Mac
 * Add select all and deselect all buttons to the file inspector tab
 * Minor interface tweaks and bug fixes
 * Danish localization
### GTK+
 * Fix minor bug in Ubuntu app indicator support
