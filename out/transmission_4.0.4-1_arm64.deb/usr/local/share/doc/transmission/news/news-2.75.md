## [Transmission 2.75](https://trac.transmissionbt.com/query?milestone=2.75&group=component&order=severity) (2012-12-13)
### Mac
 * Fix crash on non-English localizations
